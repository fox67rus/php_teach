<?php
if (isset($_POST['a']) && isset($_POST['b']) && isset($_POST['operations'])) {
    switch ($_POST['operations']){
        case '+':
            $result = (int)$_POST['a'] + (int)$_POST['b'];
            break;
        case '-':
            $result = (int)$_POST['a'] - (int)$_POST['b'];
            break;
        case '*':
            $result = (int)$_POST['a'] * (int)$_POST['b'];
            break;
        case '/':
            if ((int)$_POST['b'] == 0){
                $result = "<b>Ошибка. Деление на 0!</b>";
            }else{
                $result = (int)$_POST['a'] / (int)$_POST['b'];
            }
            break;
    }
} else
    $result = "";
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Калькулятор</title>
</head>
<body>
<p><a href="index.php">На главную</a></p>
<h2>Кнопочный калькулятор</h2>
<?php
    if (isset($_POST['a']))
        $a = $_POST['a'];
    else $a = "";
    if (isset($_POST['b']))
        $b = $_POST['b'];
    else $b = "";

?>
<form method="post">
    <input type="text" name="a"  value="<?php echo $a;?>" required>
    <input type="text" name="b"  value="<?php echo $b;?>" required>
    =
    <b><?php echo $result;?></b>
    <br>
    <input type="submit" name="operations" value="+">
    <input type="submit" name="operations" value="-">
    <input type="submit" name="operations" value="*">
    <input type="submit" name="operations" value="/">
</form>
</body>
</html>